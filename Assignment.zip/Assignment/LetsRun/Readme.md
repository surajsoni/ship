**LetsRun App**

Getting Started

Clone the repository:


```bash
git clone <repository_url>
cd LetsRun
```
Build and run the Docker containers:

```bash
docker-compose up -d
```
This will start the web server, database, and other services.

### Sign Up

Open your browser and navigate to http://localhost:9001/apis/signup/ or use a tool like curl, django or Postman to make a POST request with the following payload:

```json
{
    "name": "John Doe",
    "age": 25,
    "city": "New York"
}
```
The response will contain a private key.


### Update Total Distance Run
Make a POST request to http://localhost:9001/apis/update/ to update the total_distance_run. Provide the following payload:

```json
{
    "request": "xxxxx.yyyyy"
}
```
Replace xxxxx with a base64-encoded JSON block with user-specific information like name and distance. yyyyy is the signature of xxxxx created using the private key received during signup.

### For Example : Script for generating decoded request

```python
        msg = b"Verify key."
        signmessage = sign_message(private_key, msg)
        update_payload = generate_payload(name=name, sign_message=signmessage, distance=9, stat_option=None)
        print("Payload for /update and /mystats:")
        print(json.dumps(update_payload, indent=2))
```

#### generate_payload function for above request

```python
def generate_payload(name, sign_message, distance=None, stat_option=None):

    json_data = {
        "name": name,
        "distance": distance,
        "type": stat_option
    }

    encoded_json = base64.b64encode(json.dumps(json_data).encode('utf-8')).decode('utf-8')

    signature = base64.b64encode(sign_message).decode('utf-8')

    request_payload = {
        "request": f"{encoded_json}.{signature}"
    }

    return request_payload
```

### Get User Stats
Make a POST request to http://localhost:9001/apis/mystats/ to get the user ranking based on stat_option. Provide the following payload:


```json
{
    "request": "xxxxx.yyyyy"
}
```
Replace xxxxx with a base64-encoded JSON block with user-specific information like name and type. yyyyy is the signature of xxxxx created using the private key received during signup.

### Running Tests

Execute the following command to run the test cases:

```python

python3 manage.py test
```
This will run the test cases and provide the output.