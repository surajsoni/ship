from django.test import TestCase
from rest_framework import status
from rest_framework.test import APIClient
import json

class LetsRunTestCase(TestCase):
    def setUp(self):
        # Set up client
        self.client = APIClient()

    def test_user_signup(self):
        #/signup endpoint
        payload = {
            "name": "John Doe",
            "age": 25,
            "city": "New York",
        }
        response = self.client.post('/apis/signup/', data=json.dumps(payload), content_type='application/json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('privateKey', response.data)

    def test_user_update(self):
        #/update endpoint

        payload = {
            "request": "eyJuYW1lIjogInNoaGhoIiwgImRpc3RhbmNlIjogMTAsICJ0eXBlIjogbnVsbH0=.rBJehZlCJzygbqx04MRGPgZpZH2xqR5wb27aLydtf3x2wZb14KPtFuSfyP76Zi3q0EyyklufmJw081i2VuC9NVCPffauV07UwMYNneIAvLclO2GueSibYGAX6kw1HsAuR9t7cLuSgpOn0BJd4xBmaSLG/E40cZMo2DhzmZv1a94iEPoLAWVKvv/okjbj4mFuq02QH+3F7LlgjUxbD2YDHO6mGHdAFJMemUCEW2REyDR14PT5Pxv2M/s4j9CwOjbkJrJZQnatV3I4oZkTzDNoYdvH8pb5Ze03iz9ooVBsOOcT3InVxWEnnlPn0JVfS2AwcsZRyIBUXDa/iiY3KwcHJw=="
            }

        response = self.client.post('/apis/update/', data=json.dumps(payload), content_type='application/json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('totalDistanceRun', response.data)

    def test_user_mystats(self):
        #/mystats endpoint
        payload = {
            "request": "eyJuYW1lIjogInNoaXAiLCAiZGlzdGFuY2UiOiAxMCwgInR5cGUiOiBudWxsfQ==.isAp9gcVLzEOqMBoxTAIxprGXnldGZccqqK/3QBurFmSwYr6SJL488TwbjePyuHV0+5A3bAzOlRdc1Th/v2H174pihB2RKAsrDoAbBoCZldd3Vgl2kbMe5rfWWeBhdTRf7ERe87hKQO+HL4ht+WtH4zdT7Y8KiCDMExsssRkcjcn5AxlZWMN4ZOkdSzdhyAPSYQsmysLnt+pxrfkwJd5nub3FszEov0CJBqp3+9FiY1eTNHyrYV8KLlj6ZPPVQwZIwchgEKH1gSG/K1oCx3hj3c0VYmBz3ITSR1SIYnjCid63lz/wlB/bl7CpO5y7/RhRtVvCf5/U18K9Mr+k4HMTw=="
            }

        response = self.client.post('/apis/mystats/', data=json.dumps(payload), content_type='application/json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('ranking', response.data)
