from django.urls import path, include
from .views import *
from rest_framework import routers
router = routers.DefaultRouter()



router.register(r'signup', UserSignUpView, basename='signup')
router.register(r'update', UserUpdateView, basename='update')
router.register(r'mystats', UserMyStatsView, basename='mystats')
# API Urls
urlpatterns = [
    path('', include(router.urls)),

]
