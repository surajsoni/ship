from django.views.decorators.csrf import csrf_exempt
from rest_framework import mixins, viewsets
from rest_framework.response import Response
import logging
import json
import base64

# Custom header
from .models import UserDetails
from .serializers import UsersSerializer, UpdateSerializer
from .utils import create_rsa_key, sign_message, verify_signature

logger = logging.getLogger(__name__)

class UserSignUpView(viewsets.ViewSet, viewsets.GenericViewSet,
                              mixins.ListModelMixin, mixins.RetrieveModelMixin
                              ):
    '''
    This endpoint is used to sign up a user for the application. It expects a JSON payload in the body of the HTTP post request
    with the user's information, including name, age, and city.

    Request Payload:
        name: The full name of the user.
        age: The age of the user.
        city: The location or city where the user is located.

    Example:
        {
            "name": "John Doe",
            "age": 31,
            "city": "New York"
        }
    '''

    serializer_class = UsersSerializer
    queryset = UserDetails.objects.all()
    def create(self, request, *args, **kwargs):

        logger.debug('Signup is processing')

        # Extract the details from passed payload
        name = request.data['name']
        age = request.data['age']
        city = request.data['city']

        # Creating new records with total distance run =0
        user = UserDetails.objects.create(name=name, age=age, city=city, total_distance_run=0)

        # RSA 2048 is used as the encryption algorithm, generating a secure public/private key pair for each user during signup,
        # ensuring robust data security with a key length of 2048 bits.
        private_key, public_key = create_rsa_key()
        
        # Saved by encoding in DB
        user.public_key = base64.b64encode(public_key).decode('utf-8')
        user.save()
        logger.debug('Successfully created the record.')

        return Response({'privateKey': private_key})

class UserUpdateView(viewsets.ViewSet, viewsets.GenericViewSet,
                              mixins.ListModelMixin, mixins.UpdateModelMixin
                              ):
    '''
    Updates the user's total running distance through an HTTP post request with a JSON payload containing a request string in the format "xxxxx.yyyyy." 
    The 'xxxxx' part is a base64-encoded JSON block with user-specific information like name and distance. 
    'yyyyy' represents the signature of 'xxxxx,' created using the private key received during signup.

    Request Payload:
        {
            "request": "xxxxx.yyyyy"
        }
    
    '''

    serializer_class = UpdateSerializer
    queryset = UserDetails.objects.all()
    def create(self, request, *args, **kwargs):
        logger.debug('Update is processing')

        request_str = request.data['request']
        xValue, yValue = request_str.split('.')

        # Decode the passed data
        json_bytes = base64.b64decode(xValue.encode('utf-8'))
        signature = base64.b64decode(yValue.encode('utf-8'))
 
        # Retrieve user by name
        name = json.loads(json_bytes.decode('utf-8'))['name']
        users = UserDetails.objects.filter(name=name)
        response_data = {'totalDistanceRun': -1} 
        # Running loop
        for user in users:
            # Verify signature using the user's public key
            message = b"Verify key."
            if verify_signature( base64.b64decode(user.public_key), message, signature):

                # Update user's total distance and return the updated total distance as JSON
                distance = json.loads(json_bytes.decode('utf-8'))['distance']
                user.total_distance_run += distance
                user.save()
                response_data = {'totalDistanceRun': user.total_distance_run}
        logger.debug('Successfully updated the record.')
        return Response(response_data)

class UserMyStatsView(viewsets.ViewSet, viewsets.GenericViewSet,
                              mixins.ListModelMixin, mixins.UpdateModelMixin
                              ):
    '''
    Returns the users' ranking based on stat_option,
    stat_option determines the user's ranking, which can be based on "city" (ranking within the user's city), 
    "age" (ranking within the user's age group), or "overall" (ranking among all users in the application). 
    The 'xxxxx' part is a base64-encoded JSON block with user-specific information like name and distance. 
    'yyyyy' represents the signature of 'xxxxx,' created using the private key received during signup.

    Request Payload:
        {
            "request": "xxxxx.yyyyy"
        }
    '''

    serializer_class = UpdateSerializer
    queryset = UserDetails.objects.all()
    def create(self, request, *args, **kwargs):

        logger.debug('Stats is processing')
        request_str = request.data['request']
        xValue, yValue = request_str.split('.')

        json_bytes = base64.b64decode(xValue.encode('utf-8'))
        signature = base64.b64decode(yValue.encode('utf-8'))
 
        # Retrieve user by name
        name = json.loads(json_bytes.decode('utf-8'))['name']

        users = UserDetails.objects.filter(name=name)
        response_data = {'ranking': -1} 
        for user in users:
            # Verify signature using the user's public key
            message = b"Verify key."
            if verify_signature( base64.b64decode(user.public_key), message, signature):
                # Update user's total distance and return the updated total distance as JSON
                type = json.loads(json_bytes.decode('utf-8'))['type']
                rank = -1
                userQueryset = UserDetails.objects
                if type=='city':
                    userQueryset = userQueryset.filter(city=user.city)
                elif type=='age':
                    userQueryset = userQueryset.filter(age=user.age)
                elif type == 'overall':
                    userQueryset = userQueryset

                if userQueryset:
                    for index, obj in enumerate(userQueryset.order_by('-total_distance_run'), start=1):
                        if obj.total_distance_run == user.total_distance_run:
                            rank = index
                            break

                response_data = {'ranking': rank}
        logger.debug('Successfully fetched the record.')
        return Response(response_data)
