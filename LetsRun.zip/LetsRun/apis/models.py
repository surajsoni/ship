from django.db import models

# Create your models here.

class UserDetails(models.Model):
    '''
    Represents user details in the Lets Run! application.
    '''
    name = models.CharField(max_length=255)
    age = models.IntegerField()
    city = models.CharField(max_length=255)
    total_distance_run = models.FloatField(default=0)
    public_key = models.TextField()
    request = models.TextField(default='')

