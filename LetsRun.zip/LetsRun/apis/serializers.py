from rest_framework import serializers
from .models import *

class UsersSerializer(serializers.ModelSerializer):
    """
    Serializer for UserDetails table.
    """
    class Meta:
        model = UserDetails
        fields = ( 'name', 'age', 'city')

class UpdateSerializer(serializers.ModelSerializer):
    """
    Serializer for update and mystats payload.
    """
    class Meta:
        model = UserDetails
        fields = ('request',)
