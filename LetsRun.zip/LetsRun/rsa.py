from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import rsa, padding

def generate_key_pair():
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
        backend=default_backend()
    )

    public_key = private_key.public_key()

    # Serialize private key
    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption()
    )

    # Serialize public key
    public_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )

    return private_pem, public_pem

def sign_message(private_key, message):
    private_key = serialization.load_pem_private_key(
        private_key,
        password=None,
        backend=default_backend()
    )

    signature = private_key.sign(
        message,
        padding.PSS(
            mgf=padding.MGF1(hashes.SHA256()),
            salt_length=padding.PSS.MAX_LENGTH
        ),
        hashes.SHA256()
    )
    return signature

def verify_signature(public_key, message, signature):
    print("typeeeee", type(public_key))
    public_key = serialization.load_pem_public_key(
        public_key,
        backend=default_backend()
    )

    try:
        public_key.verify(
            signature,
            message,
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH
            ),
            hashes.SHA256()
        )
        return True
    except Exception as e:
        print(f"Signature verification failed: {e}")
        return False

# Example usage
private_key, public_key = generate_key_pair()
message = b"Hello, this is a message to sign and verify."

# Sign the message
signature = sign_message(private_key, message)
print("SSSSSS", public_key)
# Verify the signature
if verify_signature(public_key, message, signature):
    print("Signature is valid.")
else:
    print("Signature is invalid.")


# {
#   "request": "eyJuYW1lIjogInNzciIsICJkaXN0YW5jZSI6IDEwLCAidHlwZSI6IG51bGx9.b'\\x84\\xa0\\xfb`\\xfa\\x8f\\xc695I\\x15\\x05E\\x9eP\\xa3\\x05\\xad\\xaf\\xd0e7\\x05Uv\\xc0x\\xce\\xad\\xab\\x01\\'z\\xb8\\xd6o\\xf7\\xb0\\xf2-;\\x868\\x02\\xabK\\xe1x$q\\r[2\\x0b\\x1a59P\\x93\\r\\x05\\xeb\\xd4\\xff|\\xc2\\xaf\\x92\\xe6!\\xc9\\xa7\\xd0\\x9d\\xc5\\x95\\x9a\\xdc\\x16\\n\\x80\\xf1q7\\xba\\x9a[\\xbd\\xed\\xe6+D\\x7f\\x08\\x14$7\\xf4\\xb8\\xb9\\xda\\xd1\\t\\xb6\\xc1\\x07\\x8f\\xdd\\x0eT\\x00\\x17\\xd5V|[\\xbb\\xf7\\xf2\\xa1\\xa5\\xed\\xc8X\\xf1\\xb0\\x98\\xaf\\xe0\\xcdZh\\xc3\\xddS\\xe8\\xee\\xaa\\xb1\\xd2.\\r\\xe8LS_\"\\x98\\xe04\\xf79qC\\x04\\xf9\\xc2K\\xe3\\x01\\x9e~\\xc3qS(8\\nq\\xec\\xb2\\xc5\\xdb\\xb9\\xd2\\xc4\\xbf\\x00\\x19\\xdbU+<\\xa5|XG\\x019\\xb2\\xff<_#\\xa4\\xd6\\x92A\\xf9\\xf5\\xc8\\xdeZ\\xbcD\\xcd\\xc1\"\\xa0@\\xa5*y\\x91ymtZ:\\x81=\\x1d\\xc0\\xaf\\xa1\\x01\\x86\\xa1?5E\\x8bz!v\\xa5\\xdd`\\x0c\\xf9\\\\\\xf2\\xde\\xe4(W\\xf5\\xb9\\xfd\\xe7:\\x031\\xc2\\xf3q'"
# }